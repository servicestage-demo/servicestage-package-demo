#!/bin/bash
if  ps -u www -ef | grep ${APP_HOME}/packages/weather-1.0.0.jar | grep -v grep >/dev/null; then
  echo "success"
else
  echo "error: example is not running"
  exit 1
fi
