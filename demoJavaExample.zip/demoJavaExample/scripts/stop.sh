#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
JRE_HOME=${JRE_STACK_HOME}
CURRENT_USER=`whoami`
stopLog="${LOG_PATH}/stop_app.log"

function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | tee -a ${stopLog};
}

if [ "${CURRENT_USER}" != "${APP_USER}" ]
then
    writeLog "ERROR:Please change run user to ${APP_USER}"
    exit 1
fi
PID_NUM=`ps -u www -ef|grep -v grep|grep ${JRE_HOME}/bin/java|awk '{print $2}'`
kill -9 ${PID_NUM}
PID_NUM=`ps -u www -ef|grep -v grep|grep ${JRE_HOME}/bin/java|awk '{print $2}'`
if [ "${PID_NUM}" == "" ]
then
    writeLog "INFO:Stop app success!"
    exit 0
fi
writeLog "ERROR:Stop app fail!"