#!/bin/bash
. ${APP_HOME}/servicestage-vmapp/application.conf
which java
JRE_HOME=${JRE_STACK_HOME}
startLog="${LOG_PATH}/start_app.log"

function writeLog()
{
    msg="$1\n"
    printf "[`date '+%Y-%m-%d %H:%M:%S'`] $msg" | tee -a ${startLog};
}

CURRENT_USER=`whoami`
if [ "${CURRENT_USER}" != "${APP_USER}" ]
then
    writeLog "ERROR:Please change run user to ${APP_USER}"
    exit 1
fi
PID_NUM=`ps -u www -ef|grep -v grep|grep ${JRE_HOME}/bin/java|awk '{print $2}'`
if [ "${PID_NUM}" != "" ]
then
    writeLog "ERROR:application already running!"
    exit 1
fi
JAVA_OPTS="$JAVA_OPTS -server ${JAVA_TOOL_OPTIONS}"
java ${JAVA_OPTS} -jar ${APP_HOME}/packages/weather-1.0.0.jar >>${startLog} 2>&1 &